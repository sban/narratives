## A. tagPOS: Tokenize into sentence (version 0.5)
tagPOS	<- function(texts, ...) {
    ## 1 FORMALIA
    options(stringAsFactors = F)
    libs <- c("rJava", "NLP", "openNLP", "stringr", "igraph") # "tidytext" "dplyr"
    ## NB: Tjek om tidytext er nødvendig
    lapply(libs, require, character.only = T)
    ## 1.1 CLEAN_STRING
    CleanString <- function(string){
        temp 		<- tolower(string)
        temp		<- stringr::str_replace_all(temp,"[^a-zA-Z\\s]", " ")
        temp		<- stringr::str_replace_all(temp,"[\\s]+", " ")
        temp 		<- stringr::str_split(temp, " ")[[1]]
        indexes 	<- which(temp == "")
        if(length(indexes) > 0){
            stemp  <- temp[-indexes]
        }
        return(temp)
    }
    ## 1.2 Samler til POS-tagger
    s 	<- as.String(texts)
    ## 1.3 fjerner alle interviewkommentarer o.l. dvs.  '[...]' - evt  og '(...)'??
    s <-  gsub("\\[.*?\\]", "", s)
    ## 1.4 Fjerner talesprog
    vaek <- c("ahh", "aye", "naw", "eh", "eeh", "emmm", "emm", "erm", "mm")
    s <- gsub(x = s, pattern = paste(vaek, collapse = "|"),
              replacement = "", ignore.case = T )
    ## 1.5 Omformuleringer
    ## 1.5.1 Omformulerer slang til korrekt engelsk
    s <- gsub("sorta", "sort of", s)
    s <- gsub("in't tha'", "is it not", s)
    s <- gsub("innit", "is it not", s)
    s <- gsub("innut", "is it not", s)
    ## 1.5.2 Omformulerer forkortelser ol. til korrekt engelsk
    s <- tolower(s)
    s <- gsub("haven't you", "you have not", s)
    s <- gsub("didn't you",  "you did not", s)
    s <- gsub("couldn't",  "could not", s) # ny
    s <- gsub("he's",  "he is", s)
    s <- gsub("she's",  "she is", s)
    s <- gsub("it's", "it is", s)
    s <- gsub("'d ", "  would ", s) # NY: indsat mellemrum
    s <- gsub("kinda", "kind of", s)
    s <- gsub("'ve", " have", s)
    s <- gsub("let's", "let us", s)
    s <- gsub("that's", "that is", s)
    s <- gsub("there's", "there is", s)
    s <- gsub("'re", " are", s)
    s <- gsub("n't", " not", s)
    s <- gsub("'ll", " will", s)
    s <- gsub("'m", " am", s)
    s <- gsub("shan't", "shall not ", s)
    s <- gsub("'s got", "has got", s)
    s <- gsub("'s the", " is the", s)
    s <- gsub("'s your", " is your", s)
    s <- gsub("what's happened", "what has happened", s)
    ## 1.5.3 Laver tal til ord; usikker på er en god ide
    ##s <- gsub("\\<1\\>", "one", s)
    ##s <- gsub("\\<2\\>", "two", s)
    ##s <- gsub("\\<3\\>", "three", s)
    ##s <- gsub("\\<4\\>", "four", s)
    ##s <- gsub("\\<5\\>", "five", s)
    ## Fejl i POS-taggeren
    s <- gsub("open minded", "open-minded", s)

    ## Transkriptionsnoter
    s <- gsub("\\%%OMITTED TEXT\\##", "", s)

    ## tegn
    s <- gsub("\\?",  "", s)
    s <- gsub("\\#",  "", s)
    s <- gsub("\\%",  "percent", s)
    s <- gsub(" - ",  " ", s)
    s <- gsub("- ",  " ", s)
    s <- gsub("\\$", "", s)  # NY
    s <- gsub("@",  "", s)
    s <- gsub("\\(",  "", s)
    s <- gsub(")",  "", s)
    s <- gsub("\\[",  "", s)
    s <- gsub("\\.",  "", s)
    s <- gsub(",",  "", s)
    s <- gsub("\\&",  "", s)
    s <- gsub("'",  "", s)
    s <- gsub(" i ",  " I ", s)
    s <- gsub("  ",  " ", s)
    ## Problemer med -ord og ord-
    s <-gsub("d-$", "d", s)
    s <-gsub("f-$", "f", s)
    s <-gsub("^-w", "w", s)
    s <-gsub("^-y", "y", s)
    s <- gsub(" -(\\w)", "\\1", s)
    s <- gsub("(\\w)-", "\\1", s)







    ## For POS-taggeren: stort I; NY
    s <- gsub("\\<i\\>", "I", s)
    ## Hvis s er tom
    if (s == "  "|  s == " " | s == "") {
        res <- list(POSorg = "None", POStagged = "None", POStags = "None", original = texts)
    } else
                        {
### ellers
                            ## 1.6 Selve POS-tagger
                            WrdTokAnn <- Maxent_Word_Token_Annotator()
                            a2 	<- Annotation(1L, "sentence", 1L, nchar(s))
                            a2 	<- annotate(s, WrdTokAnn, a2)
                            a3 	<- annotate(s, Maxent_POS_Tag_Annotator(), a2)
                            a3w <- a3[a3$type == "word"]
                            POSorg <- CleanString(s)
                            POSorg   <-  POSorg[POSorg != ""]  # NY
                            POStags 	<- unlist(lapply(a3w$features, `[[`, "POS"))
                            POStagged	<- paste(sprintf("%s/%s", s[a3w], POStags), collapse = " ")
                            s <- strsplit(s, " ")
                            s <-   unlist(s)
                            s <- s[!s == ""]
                            res<- list(POSorg = s, POStagged = POStagged, POStags = POStags, original = texts)
                        }
    return(res)
}


## B. autoPOS (Version 0.5) - NY STRUKTUR OG RENS
autoPOS	<- function(t, ...) {
    ## 1. Formialia
    ## 1.1 Samlet sætning
    tmp <- paste(t$POSorg, collapse = " ")
    ## 1.2.1  Renser POStags (= tags)
    tags <- t$POStags
    tags <- tags[!tags == "-LRB-"]
    tags <- tags[!tags == "-RRB-"]
    tags <- tags[!tags == ":"]
    tags <- tags[!tags == "@"]
    tags <- tags[!tags == "-"]
    tags <- tags[!tags == "."]
    tags <- tags[!tags == ","]
    tags <- tags[!tags == "["]
    tags <- tags[!tags == "]"]
    tags <- tags[!tags == "''"]
    tags <- tags[!tags == "."]
    ## 1.2.2  Renser POSorg;; ny
    t$POSorg <- t$POSorg[!t$POSorg == ""]
    t$POSorg <- t$POSorg[!t$POSorg == "-"]
    t$POSorg <- t$POSorg[!t$POSorg == ","]
    ## 1.2.3 Fjerner irrelevante ord
    relevant <- tags
    relevant <- relevant[relevant != "UH"]
    ## 1.3 Nok info til at fortsaette
    if  (length(relevant) == 0) {
        C <- data.frame(
             SubSen = 1,
             S = "?",
             A = "?",
             O =  "?",
             txt = t$original,
             stringsAsFactors=FALSE)
    } else {
                ## 2. ORDNER ORD
                ## 2.1 Opretter ordmatrice
                t$POSorg     <- t$POSorg[t$POSorg != ""]
                txt.words    <- data.frame(word = t$POSorg,
                                           POS = tags,
                                           stringsAsFactors=FALSE)


               ### 2.1.1 Ordner ordgrupper
               ### 2.1.1.1 Svære ordstillinger
               #### 2.1.1.1.1 "The lion chased the tourist lazily through the bush"
				 if (nrow(txt.words) > 8) {
                 for (i in 1:(nrow(txt.words)-1)) {
                 	if (!is.na(txt.words[i + 1, 1]) &
                 		!is.na(txt.words[i + 7, 1])) {
                 			if(txt.words[i, 2] == "NN" &
                 			txt.words[i + 1, 2] == "VBD" &
							txt.words[i + 2, 2] == "DT" &
							txt.words[i + 4, 2] == "RB" &
							txt.words[i + 5, 2] == "IN" &
							txt.words[i + 6, 2] == "DT" &
							txt.words[i + 7, 2] == "NN") {
                 			## Tillaegsord
                 			#txt.words[i + 1, 1] <- paste(txt.words[i + 4, 1],txt.words[i + 1, 1])
 							txt.words <- txt.words[-c(i + 4, i + 7), ]
 						            				}
 						}
 					 }
					}

               #### 2.1.1.1.2 "O = vase on the floor";; NY (sikkert ikke stabil i laengden)
				 if (nrow(txt.words) > 4) {
                 for (i in 1:(nrow(txt.words)-1)) {
                 	if (!is.na(txt.words[i + 3, 1])) {
                 			if(txt.words[i, 2] == "NN" &
                 			txt.words[i + 1, 2] == "IN" &
							txt.words[i + 2, 2] == "DT" &
							txt.words[i + 3, 2] == "NN") {
                 			## Hvis de skal sammenlaegges
                 			#txt.words[i, 1] <- paste(txt.words[i, 1],txt.words[i + 1, 1],
                 			#						 txt.words[i + 2, 1], txt.words[i + 3, 1])
 							#txt.words <- txt.words[-c(i + 1, i + 2, i + 3), ]
 							## Hvis IN-leddet skal vaek
 							txt.words <- txt.words[-c(i + 2, i + 3), ]
 							        				}
 						}
 					 }
					}




               #### 2.1.2 Simplere
               #### 2.1.2.1 "sort-of-x"
               if (nrow(txt.words) > 2) {
                for (i in 1:(nrow(txt.words)-1)) {
					if(txt.words[i, 1] == "sort" &
 						txt.words[i + 1, 1] == "of" &
 						(txt.words[i + 2, 2] == "NN" | txt.words[i + 2, 2] == "VBN")  &
 						!is.na(txt.words[i + 2, 1])				) {
 						txt.words[i, 1] <- paste("sort of", txt.words[i + 2, 1])
 						txt.words <- txt.words[-c(i + 1, i + 2), ]
 						}
 					}
				}

                #### 2.1.2.2 "had-to-x"
                if (nrow(txt.words) > 2) {
                for (i in 1:(nrow(txt.words)-1)) {
					if(txt.words[i, 1] == "had" &
 						txt.words[i + 1, 1] == "to" &
 						txt.words[i + 2, 2] == "VB" &
 						!is.na(txt.words[i + 2, 1] )				) {
 						txt.words[i, 1] <- paste("had to", txt.words[i + 2, 1])
 						txt.words <- txt.words[-c(i + 1, i + 2), ]
 						}
 					}
				}

        ## 2.1.2.3 "part-of-x"
        if (nrow(txt.words) > 2) {
                   for (i in 1:(nrow(txt.words)-1)) {
                       if(txt.words[i, 1] == "part" &
                       txt.words[i + 1, 1] == "of" &
                       txt.words[i + 2, 2] == "PRP" &
                       !is.na(txt.words[i + 2, 1])) {
                           txt.words[i, 1] <- paste("part of", txt.words[i + 2, 1])
                           txt.words <- txt.words[-c(i + 1, i + 2), ]
                       }
                   }
        }
        ## 2.1.2.3 "x-years-old"  NY
        if (nrow(txt.words) > 2) {
                    for (i in 1:(nrow(txt.words)-1)) {
                     if (!is.na(txt.words[i + 1, 1]) & !is.na(txt.words[i + 2, 1])) {
                            if(txt.words[i, 2] == "CD" &
                           txt.words[i + 1, 1] == "years" &
                           txt.words[i + 2, 1] == "old"){
                            txt.words[i, 1] <- paste(txt.words[i, 1], "years old")
 						txt.words <- txt.words[-c(i + 1, i + 2), ]
 							}
 						}
                 }
			}

        ## 2.1.2.4 Me and X; NY
        if (nrow(txt.words) > 2) {
                    for (i in 1:(nrow(txt.words)-1)) {
                     if (!is.na(txt.words[i + 1, 1]) & !is.na(txt.words[i + 2, 1])) {
                            if(txt.words[i, 1] == "me" &
                           txt.words[i + 1, 1] == "and" &
                           txt.words[i + 2, 2] == "NNP"){
                            txt.words[i, 1] <- paste(txt.words[i+2, 1], "and me")
 						txt.words <- txt.words[-c(i + 1, i + 2), ]
 							}
 						}
 					}
				}

			 	#### -- X and Me
               	if (nrow(txt.words) > 2) {
                 for (i in 1:(nrow(txt.words)-1)) {
                 	if (!is.na(txt.words[i + 1, 1]) & !is.na(txt.words[i + 2, 1])) {
                 	if((txt.words[i, 2] == "NNP" | txt.words[i, 2] == "NN") &
						txt.words[i + 1, 1] == "and" &
						txt.words[i + 2, 1] == "me"){
 						txt.words[i, 1] <- paste(txt.words[i, 1], "and me")
 						txt.words <- txt.words[-c(i + 1, i + 2), ]
 							}
 						}
 					}
				}

              ### 2.1.2.5 lot more; NY
              if (nrow(txt.words) > 2) {
                 for (i in 1:(nrow(txt.words)-1)) {
                 	if (!is.na(txt.words[i + 1, 1]) &
                 		!is.na(txt.words[i + 2, 1])) {
                 	if((txt.words[i, 1] == "lot") &
						txt.words[i + 1, 1] == "more" &
						txt.words[i + 2, 2] == "JJ"){
 						txt.words[i, 1] <- paste("lot more", txt.words[i+2, 1])
 						txt.words <- txt.words[-c(i + 1, i + 2), ]
 							}
 						}
 					}
				}

              if (nrow(txt.words) > 2) {
                 for (i in 1:(nrow(txt.words)-1)) {
                 	if (!is.na(txt.words[i + 1, 1])) {
                 	if(txt.words[i, 1] == "lot" &
						txt.words[i + 1, 1] == "more") {
 						txt.words[i, 1] <- paste("lot more")
 						txt.words <- txt.words[-c(i + 1), ]
 							}
 						}
 					}
				}

### 2.1.2.5 JJ og NN (alene for slutningen); NY
                                        #    S <- txt.words
                                        #     txt.words  <- S
                if (nrow(txt.words) > 1) {
                    for (i in 1:(nrow(txt.words)-1)) {
                 	if (!is.na(txt.words[i + 1, 1]) &
                            is.na(txt.words[i + 2, 1])) {
                            if((txt.words[i, 2] == "JJ") &
                               (txt.words[i + 1, 2] == "NN")) {
                                txt.words[i, 1] <- paste(txt.words[i, 1], txt.words[i + 1, 1])
                                txt.words <- txt.words[-c(i + 1), ]
                            }
                        }
                    }
                }
                if (nrow(txt.words) > 1) {
                    for (i in 1:(nrow(txt.words)-1)) {
                 	if (!is.na(txt.words[i + 1, 1]) &
                            is.na(txt.words[i + 2, 1])) {
                            if((txt.words[i, 2] == "NN") &
                               (txt.words[i + 1, 2] == "JJ")) {
                                txt.words[i, 1] <- paste(txt.words[i, 1], txt.words[i + 1, 1])
                                txt.words <- txt.words[-c(i + 1), ]
                            }
                        }
                    }
                }

                ## 2.1.2.6 X and Y; NY
                ##S <- txt.words
                ##txt.words  <- S
                if (nrow(txt.words) > 1) {
                    for (i in 1:(nrow(txt.words)-1)) {
                 	if (!is.na(txt.words[i + 1, 1]) &
                 	!is.na(txt.words[i + 2, 1])) {
                 	if((txt.words[i, 2] == "NN" | txt.words[i, 2] == "NNS"
                 		| txt.words[i, 2] == "PRP") &
						(txt.words[i + 1, 1] == "and") &
						(txt.words[i + 2, 2] == "NN" |
						txt.words[i + 2, 2] == "PRP" |
						txt.words[i + 2, 2] == "NNS")) {
 						txt.words[i, 1] <- paste(txt.words[i, 1], "and", txt.words[i + 2, 1])
 						txt.words <- txt.words[-c(i + 1, i + 2), ]
 							}
 						}
 					}
				}
        ## 2.1.3 Ændre ord-klasser
        ## 2.1.3.1 Muliggør tal kan være en del af O-objektet, hvis der ikke er et NN; NY
        if ((sum((txt.words$POS == "NN"), na.rm=FALSE) < 2) & (any(txt.words$POS == "CD"))) {
            txt.words$POS[txt.words$POS == "CD"] <- "NN"
        }
        ## 2.2 Andre sammenlægninger
        list(t$POSorg, tags)
        txt.words$no <-  1:nrow(txt.words)
        options(warn = -1)
        ## 2.2.1  TO VB VED SIDEN AF HINANDEN
        v.merge <- txt.words[(substr(txt.words$POS, 1, 2) == "VB" | txt.words$POS == "VB"),]
        v.merge <- expand.grid(v.merge[,3], v.merge[,3])
        colnames(v.merge) <- c("no.v1", "no.v2")
        v.merge <-  merge(txt.words[,c(1,3)], v.merge, by.x = "no", by.y = "no.v1")
                v.merge <- v.merge[,c(1,3,2)]
                colnames(v.merge) <- c("no.v1", "no.v2", "word.v1")
                v.merge <-  merge(txt.words[,c(1,3)], v.merge, by.x = "no", by.y = "no.v2")
                v.merge <- v.merge[,c(3, 1, 4,2)]
                colnames(v.merge) <- c("no.v1", "no.v2", "word.v1", "word.v2")
                v.merge$diff <- v.merge$no.v1 -v.merge$no.v2
                v.merge <-v.merge[v.merge$diff == -1,]
                v.merge <- v.merge[!duplicated(v.merge),]
                ## warning OK
                if (nrow(v.merge) > 0) {
                    v.merge$new <- paste(v.merge$word.v1, v.merge$word.v2)
                    v.merge <-  v.merge[, c(1,6)]
                    colnames(v.merge)	<- c("no", "new")
                    txt.words$word[v.merge$no == txt.words$no] <- v.merge$new
                    txt.words$word[txt.words$no == (txt.words$no[v.merge$no == txt.words$no]+1)] <- NA
                    txt.words <- na.omit(txt.words)
                }

                ## 2.2.2  JJ+JJ VED SIDEN AF HINANDEN
                jj.merge <- txt.words[(substr(txt.words$POS, 1, 2) == "JJ" | txt.words$POS == "JJ"),]
                tmp <- expand.grid(jj.merge[,2], jj.merge[,2])
                tmp2 <- expand.grid(jj.merge[,1], jj.merge[,1])
                jj.merge <- expand.grid(jj.merge[,3], jj.merge[,3])
                jj.merge <- cbind(jj.merge, tmp)
                jj.merge <- cbind(jj.merge, tmp2)
                colnames(jj.merge) <- c("no.o1", "no.o2", "pos.o1","pos.02", "w.o1", "w.o2")
                jj.merge$diff <- jj.merge$no.o1 -jj.merge$no.o2
                jj.merge <-jj.merge[jj.merge$diff == -1,]
                jj.merge <- jj.merge[!duplicated(jj.merge),]
                ## warning OK
                if (nrow(jj.merge) > 0) {
                    jj.merge$new <- paste(jj.merge$w.o1, jj.merge$w.o2)
                    jj.merge <-  jj.merge[, c("no.o1","new")]
                    colnames(jj.merge)	<- c("no", "new")
                    txt.words$word[jj.merge$no == txt.words$no] <- jj.merge$new
                    txt.words$word[txt.words$no == (txt.words$no[jj.merge$no == txt.words$no]+1)] <- NA
                    txt.words <- na.omit(txt.words)
                }

                ## 2.2.3 VB+RB VED SIDEN AF HINANDEN
                vr.merge <- txt.words[(substr(txt.words$POS, 1, 2) == "VB" | txt.words$POS == "RB"),]
                tmp <- expand.grid(vr.merge[,2], vr.merge[,2])
                tmp2 <- expand.grid(vr.merge[,1], vr.merge[,1])
                vr.merge <- expand.grid(vr.merge[,3], vr.merge[,3])
                vr.merge <- cbind(vr.merge, tmp)
                vr.merge <- cbind(vr.merge, tmp2)
                colnames(vr.merge) <- c("no.o1", "no.o2", "pos.o1","pos.02", "w.o1", "w.o2")
                vr.merge$diff <- vr.merge$no.o1 - vr.merge$no.o2
                vr.merge <-vr.merge[vr.merge$diff == -1,]
                vr.merge <- vr.merge[!duplicated(vr.merge),]
                vr.merge$new <- paste(vr.merge$w.o1, vr.merge$w.o2)

                ##  2.2.3.1 Foerste saetning (enkeltvis)
                match <-  vr.merge[1,]
                if (nrow(match) > 0 & !is.na(match$new)) {
                    match <-  match[, c("no.o1","new")]
                    colnames(match)	<- c("no", "new")
                    txt.words$word[match$no == txt.words$no] <- match$new
                    txt.words$word[txt.words$no == (txt.words$no[match$no == txt.words$no]+1)] <- NA
                    ## No skal have plus een for at sammensaettes korrekt ved efterfoelgende iterationer
                    txt.words$no[match$no == txt.words$no] <- txt.words$no[match$no == txt.words$no]  + 1
                    txt.words <- na.omit(txt.words)
                }

                ## 2.2.3.2 efterfoelgende itegration
                maxTAL  <-nrow( txt.words[(substr(txt.words$POS, 1, 2) == "VB" |
                                           txt.words$POS == "RB" |
                                           txt.words$POS == "MD"),])
                tal <- 1
                if (maxTAL > 1 )  { ## ændret fra > 0
                    repeat {
                        tal  = tal+1
                        vr.merge <- txt.words[(substr(txt.words$POS, 1, 2) == "VB" |
                                               txt.words$POS == "RB" |
                                               txt.words$POS == "MD"),]
                        tmp <- expand.grid(vr.merge[,2], vr.merge[,2])
                        tmp2 <- expand.grid(vr.merge[,1], vr.merge[,1])
                        vr.merge <- expand.grid(vr.merge[,3], vr.merge[,3])
                        vr.merge <- cbind(vr.merge, tmp)
                        vr.merge <- cbind(vr.merge, tmp2)
                        colnames(vr.merge) <- c("no.o1", "no.o2", "pos.o1","pos.02", "w.o1", "w.o2")
                        vr.merge$diff <- vr.merge$no.o1 - vr.merge$no.o2
                        vr.merge <-vr.merge[vr.merge$diff == -1,]
                        vr.merge <- vr.merge[!duplicated(vr.merge),]
                        vr.merge$new <- paste(vr.merge$w.o1, vr.merge$w.o2)
                        match <-  vr.merge[1,]
                        if ((nrow(match) > 0) & any(!is.na(match))) {
                            match <-  match[, c("no.o1","new")]
                            colnames(match)	<- c("no", "new")
                            txt.words$word[match$no == txt.words$no] <- match$new
                            txt.words$word[txt.words$no == (txt.words$no[match$no == txt.words$no]+1)] <- NA
                            txt.words$no[match$no == txt.words$no] <- txt.words$no[match$no == txt.words$no]  + 1
                            txt.words <- na.omit(txt.words)
                        }
                        if (tal == maxTAL){
                            break
                        }
                    }
                }
                ## 2.X VB+TO+VB (8) & JJ+NN (10)
                ## fx 'have to do'
                ## NB ordsammensaetninger boer holdes adskilt, hvis der er " ,"




## NB FIX: I [.] I -> I "verb" I
## NB FIX: "sort of X" -> eet O

### NB: ALLE DISSE 2'ER PAR SKAL GEMMES FOR POST-ANALYSER

                ## 3. SAMLER OG OPRETTER ALLE MULIGE SV-PAR (nu med JJ (tillaegsord)
                S <- txt.words[(substr(txt.words$POS, 1, 2) == "NN" |
                                txt.words$POS == "PRP" |
                                substr(txt.words$POS, 1, 3) == "PRP$" |
                                txt.words$POS == "JJ" |
                                txt.words$POS == "EX"),]

                V <- txt.words[(substr(txt.words$POS, 1, 2) == "VB" |
                                txt.words$POS == "RD" |
                                txt.words$POS == "MD" |
                                txt.words$POS == "RB"),]
                S <- S[order(S$no), ]
                V <- V[order(V$no), ]
                SV <- rbind(S, V, stringsAsFactors=FALSE)

    ## 4. ENKLE SCENARIER
    ## 4.1 HVIS INGEN V
    C 	<- list()

    if (length(V$word) == 0) {
        C <- data.frame(SubSen = "?", S = "?", A= "?", O = "?")
    } else {
        ## ELLERS FORTSAETTER
        if (length(V$word) > 0) {
            for (n in 1:length(V$word)) {
                C[[n]] <- c(n, "?", V$word[n], "?")
            }
        } else {
            C <- data.frame("?", "?", "?", "?")
        }
        if (length(V) > 0) {
            C <- data.frame(matrix(unlist(C), nrow=length(C), byrow=T), stringsAsFactors=FALSE)
        }
        colnames(C) <- 	c("subsentence", "S", "V", "O")


        ## 4.3 Hvis der IKKE er et O (men ét S) ## NY (se v30)
        if (nrow(S) == 1 & nrow(V) == 1) {
            C$S <- S$word
            C$O <- "?"
            C <- data.frame(
                SubSen = C$subsentence,
                S = C$S,
                A = C$V,
                O =C$O,
                stringsAsFactors=FALSE)
        }

        ## 4.2 Èt S og èt O
        if (nrow(S) == 2 & nrow(V) == 1) {
            C$S <- S$word[1]
            S.r <-  S[ !(S$word %in% C$S)   , ]
            S.r <- S.r[order(S.r$no), ]
            C$O <- S.r$word[1]
            C <- data.frame(
                SubSen = C$subsentence,
                S = C$S,
                A = C$V, # new
                O =C$O,
                stringsAsFactors=FALSE)
                if (is.na(C$O) & length(S$word) > 1) { # NY
                	C$O <- S$word[2]
                	}
        }

        ## 4.4 Intet S
        if (nrow(S) == 0 ) {
             C <- data.frame(
                SubSen =  1:nrow(V),
                S = "?",
                A =V$word,
                O ="?",
                no.S = "?",
                stringsAsFactors=FALSE)
        }


        ## 4.5 Flere V end S
        if (nrow(S) < nrow(V)) {
            SV.diff <- expand.grid(S$no, V$no, stringsAsFactors=FALSE)
            SV.diff$diff <- SV.diff$Var2-SV.diff$Var1
            SV.diff <- merge(SV.diff, S, by.x = "Var1", by.y = "no")
            colnames(SV.diff) <- c("no.S", "no.V", "diff", "w.S", "p.S")
            SV.diff <- merge(SV.diff, V, by.x = "no.V", by.y = "no")
            SV.diff <-SV.diff[SV.diff$diff > 0,]

            C <- data.frame(
                SubSen = 1:nrow(V),
                S = "?",
                A = V$word,
                no.V = V$no,
                O ="?")
            C <- merge(C, SV.diff, by = "no.V", all = T)
            C <- data.frame(
                SubSen = C$SubSen,
                S = C$w.S,
                A = C$A,
                O = C$O,
                no.S = "?",
                stringsAsFactors=FALSE)
        }

        ## 5. KOMPLEKSE SCENARIER (Hvis der er flere V'er O'er)
        if (nrow(S) > 1 ) { ## old: (nrow(S) > 0 )

        ## 5.1 OPRETTER SV-MATRICEN
        SV.diff <- expand.grid(S$no, V$no, stringsAsFactors=FALSE)
        SV.diff$diff <- SV.diff$Var2-SV.diff$Var1
        SV.diff <- merge(SV.diff, S, by.x = "Var1", by.y = "no")
        colnames(SV.diff) <- c("no.S", "no.V", "diff", "w.S", "p.S")
        SV.diff <- merge(SV.diff, V, by.x = "no.V", by.y = "no")
        SV.diff <-SV.diff[SV.diff$diff > 0,]

            ## 5.1.2 Stopper hvis SV.diff er tom
            if (nrow(SV.diff) == 0) {
                C <- data.frame(
                    SubSen = 1:nrow(V),
                    S = "?",
                    A = V$word,
                    O ="?",
                    no.S = "?",
                    stringsAsFactors=FALSE)

               }  else {

                   SV.diff <- SV.diff[ order(SV.diff$no.S, SV.diff$diff) , ]
                   SV.diff <- SV.diff[!duplicated(SV.diff$no.S),]
                   SV.diff <- SV.diff[ order(SV.diff$no.V, SV.diff$diff) , ]
                   SV.diff <-   SV.diff[!duplicated(SV.diff$no.V),] ## ny?

                   ## 5.2  Èt V og mange S'er
                   if (nrow(S) > 1  & nrow(V) == 1 & C$O == "?") {
                       C <- data.frame(
                           SubSen = C$subsentence,
                           S = SV.diff$w.S,
                           A = SV.diff$word,
                           no.S =  SV.diff$no.S,
                           O ="?")
                   }

                   ## 5.3 Mange V'er og mange S'er
                   if (nrow(S) > 1 & nrow(V) > 1) {

                       ## 5.3.1 Hvis antallet af S passer med antallet af  V
                       if (length(C$S) == length(SV.diff$w.S)) {
                           C[C$V  ==  SV.diff$word, ]$S <- SV.diff$w.S
                           ## C$V.POS  # skal fjernes ved endelige version
                           C <- data.frame(
                               SubSen = C$subsentence,
                               S = SV.diff$w.S,
                               A = SV.diff$word,
                               O =  "?",
                               no.S =  SV.diff$no.S,
                               ## S.POS = SV.diff$p.S,
                               stringsAsFactors=FALSE)
                       } else {

                           ## 5.3.1 Hvis antallet af S er over antallet af V
                           C <- data.frame(
                               SubSen =  1:nrow(SV.diff),
                               S = SV.diff$w.S,
                               A = SV.diff$word,
                               O =  "?",
                               no.S =  SV.diff$no.S,
                               ## S.POS = SV.diff$p.S,
                               stringsAsFactors=FALSE)
                       }
                   }
               }
        ## 6. OBJEKTER
        ## 6.1 Opretter rest.S (S.r)
        S.r <-  S[ !(S$word %in% C$S)   , ]
        S.r <- S.r[order(S.r$no), ]

        ## 6.2 Hvis alle i S er PRP og ALLE i rest.S er NN
        if (all(C$S.POS == "PRP") &  nrow(S.r) == 1 & all(S.r$POS == "NN"))  {
            C$O	<- S.r$word
        }
        ## 6.3 RESTEN
        if (all(C$O == "?"))   {
            SO.diff <- expand.grid(S$no, S$no, stringsAsFactors=FALSE)
            SO.diff <- merge(SO.diff, S[, c("no", "word")], by.x = "Var2", by.y = "no")
            colnames(SO.diff)  <- c("no.S1", "no.S2", "w.S1")
            SO.diff <- 	merge(SO.diff, S[, c("no","word")], by.x = "no.S2", by.y = "no")
            colnames(SO.diff) <- c("no.S1", "no.S2", "w.S2", "w.S1")
            SO.diff <- SO.diff[ order(SO.diff$no.S1, SO.diff$no.S2) , ]
            SO.diff <- SO.diff[,c(1,2,4,3)]
            SO.diff$diff <- SO.diff$no.S1 - SO.diff$no.S2
            SO.diff <- SO.diff[!SO.diff$diff == 0,]
            SO.diff <- SO.diff[SO.diff$diff < 0,]
            SO.diff <- SO.diff[!duplicated(SO.diff$no.S1),]
            if (nrow(SO.diff) > 0) {
                C <- merge(C, SO.diff[, c("no.S1","w.S2")], by.x = "no.S",
                           by.y = "no.S1", all.x = TRUE)
                C$O <- C$w.S2 # flyttet
                C$w.S2 <- NULL
            }

            C$no.S <- NULL

            ##C$S[is.na(C$S)] <- "?"
            C$O[is.na(C$O)] <- "?"
            C$S[is.na(C$S)] <- "?"
             C[is.na(C)] <- "?"
        }
        }
        ## 7. Renser og lukker
        ## C$pos.S <- C$S.POS
        ## C$pos.V <-
        ##  C$pos.O <-
            }
                C$SubSen =  1:nrow(C) ## Overruler den forrige def.
                C$S[C$S == "i"] <-  "I"
                C$txt <- t$original

 }
    C$no.S <- NULL
    C <- C[C$S != "?" | C$S != NA,] # NY
    C <- na.omit(C) # NY
    return(C)
}

##  C:Extra progams: MODIFY
## 1. Divide quote into sentences;
SplitSentences <- function(texts){
    ## ignore "(..)"
    ## subtexts <- strsplit(texts, "[.]") # old
    ## NY: fjerner brackets
    s <-  gsub("\\[.*?\\]", "", texts)
    subtexts <-  strsplit(s, ". ", fixed = TRUE)
    trim <- function (x) gsub("^\\s+|\\s+$", "", x)
    subtexts <-  lapply(subtexts, trim)
    subtexts <-    data.frame(matrix(unlist(subtexts), nrow=length(subtexts),
                      byrow=T), stringsAsFactors=FALSE)
    subtexts <- t(subtexts)
    attributes(subtexts) <- NULL
    return(subtexts)
}

## D:  Samlet program for alle teksterne i ét
svoPOS  <- function(texts, ...) {
    res <- lapply(texts, tagPOS)
    res <- lapply(res, autoPOS)
    return(res)
}

SVA <-  function(texts, ...) {
    require(plyr)
    t <- lapply(SplitSentences(texts), svoPOS)
    t <- ldply(t, data.frame)
    return(t)
}


## G: Grafmodulerne
 graphSA <- function(input, minE = NULL, minW = NULL) {
    require(igraph)
    # Filter
    input <- input[input$O != "?",]
    if(is.null(minE))
     minE <- 0
    if(is.null(minW))
      minW <- 0
    # Opretter data
    net.dat <- as.data.frame(table(input$S, input$A))
    colnames(net.dat) <- c("from", "to", "weight")
    # Filtrer for weight
    net.dat <- net.dat[net.dat$weight > minW,]
    # grafdat
    mod.network <-graph_from_data_frame(net.dat, directed=F)
    # Filtrer for degree
    v <-V(mod.network)[degree(mod.network) < minE]
    mod.network <-delete.vertices(mod.network, V(mod.network)[v])
    mod.network<- delete.edges(mod.network, V(mod.network)[v])
    # plotter
    return(plot(simplify(mod.network),vertex.color="white",
            vertex.size=0.5, vertex.label.color= "black",
            remove.multiple = T, remove.loops = T,
            edge.arrow.size=44.5, vertex.label.color="black", 
            vertex.label.dist=1.0))
		}

 graphSO <- function(input, minE = NULL, minW = NULL) {
   require(igraph)
   # Filter
   input <- input[input$O != "?",]
   input <- input[input$S != "?",]
   if(is.null(minE))
     minE <- 0
   if(is.null(minW))
     minW <- 0
   # Opretter data
   net.dat <- as.data.frame(table(input$S, input$O))
   colnames(net.dat) <- c("from", "to", "weight")
   # Filtrer for weight
   net.dat <- net.dat[net.dat$weight > minW,]
   # grafdat
   mod.network <-graph_from_data_frame(net.dat, directed=F)
   # Filtrer for degree
   v <-V(mod.network)[degree(mod.network) < minE]
   mod.network <-delete.vertices(mod.network, V(mod.network)[v])
   mod.network<- delete.edges(mod.network, V(mod.network)[v])
   # plotter
   return(plot(simplify(mod.network),vertex.color="white",
               vertex.size=0.5, vertex.label.color= "black",
               remove.multiple = T, remove.loops = T,
               edge.arrow.size=44.5, vertex.label.color="black", 
               vertex.label.dist=1.0))
 }
 
 
 graphSAO <- function(input, minE = NULL, minW = NULL) {
   require(igraph)
   # S = S + O
  input <- input[input$O != "?",]
  input <- input[input$S != "?",]
  test.a <- input[,c(2,3)]
  test.b <- input[,c(4,3)]
  test.c <- input[,c(3,4)] # forbinder S med O
  colnames(test.a) <- c("S", "A")
  colnames(test.b) <- c("S", "A")
  colnames(test.c) <- c("S", "A")
  test <- rbind(test.a, test.b, test.c) 
  # Filter 
  if(is.null(minE))
     minE <- 0
   if(is.null(minW))
     minW <- 0
   # Opretter data
   net.dat <- as.data.frame(table(input$S, input$A))
   colnames(net.dat) <- c("from", "to", "weight")
   # Filtrer for weight
   net.dat <- net.dat[net.dat$weight > minW,]
   # grafdat
   mod.network <-graph_from_data_frame(net.dat, directed=F)
   # Filtrer for degree
   v <-V(mod.network)[degree(mod.network) < minE]
   mod.network <-delete.vertices(mod.network, V(mod.network)[v])
   mod.network<- delete.edges(mod.network, V(mod.network)[v])
   # plotter
   return(plot(simplify(mod.network),vertex.color="white",
               vertex.size=0.5, vertex.label.color= "black",
               remove.multiple = T, remove.loops = T,
               edge.arrow.size=44.5, vertex.label.color="black", 
               vertex.label.dist=1.0))
 }



### F: Table functions
 tab.s <-  function(input, nb = 10, verb = " ") {
   if (verb == " ") {
   t <-  sort(table(input$S),decreasing=TRUE)[1:nb]
   } else {
    t <-  sort(table(input[input$A == verb,]$S),decreasing=TRUE)[1:nb]
   }
    return(t)
 }
 

 tab.a <-  function(input, nb = 10, subj = " ") {
   if (subj == " ") {
     t <-  sort(table(input$A),decreasing=TRUE)[1:nb]
   } else {
     t <-  sort(table(input[input$S == subj,]$A),decreasing=TRUE)[1:nb]
   }
   return(t)
 }



## Mulige extra features
## 1. Personlige pronomer kan ikke være S
## 5. Gem tillægsord og sæt dem foran objekterne
## 6. Sentiment analyse af verber - hvilke subjekter er mest negative/positive?
## 7. Problematik med "AND" (sætter som ét subjekt)

